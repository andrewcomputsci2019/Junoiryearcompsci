//
//  factheader.h
//  uilab
//
//  Created by Pegg, Andrew on 12/10/19.
//  Copyright © 2019 Pegg, Andrew. All rights reserved.
//

#ifndef factheader_h
#define factheader_h
struct 
{
    char* fact[10000];
    
}typedef ff;
char* funfact(void);

#endif /* factheader_h */
