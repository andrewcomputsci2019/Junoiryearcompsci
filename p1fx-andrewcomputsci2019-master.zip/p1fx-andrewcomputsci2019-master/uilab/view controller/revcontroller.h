//
//  revcontroller.h
//  uilab
//
//  Created by Pegg, Andrew on 12/4/19.
//  Copyright © 2019 Pegg, Andrew. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface revcontroller : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *Outputtext;
@property (weak, nonatomic) IBOutlet UITextField *InputText;
@property (weak, nonatomic) IBOutlet UILabel *polo;
@property (weak, nonatomic) IBOutlet UILabel *time1;
@property (weak, nonatomic) IBOutlet UILabel *time2;
@property (weak, nonatomic) IBOutlet UILabel *time3;

@end

NS_ASSUME_NONNULL_END
