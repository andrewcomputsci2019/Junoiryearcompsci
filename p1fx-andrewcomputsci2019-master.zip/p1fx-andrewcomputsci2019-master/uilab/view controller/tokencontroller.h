//
//  tokencontroller.h
//  uilab
//
//  Created by Pegg, Andrew on 12/13/19.
//  Copyright © 2019 Pegg, Andrew. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface tokencontroller : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *output;
@property (weak, nonatomic) IBOutlet UITextField *input;
@property (weak, nonatomic) IBOutlet UILabel *piglat;
@property (weak, nonatomic) IBOutlet UILabel *shorthand;
@property (weak, nonatomic) IBOutlet UILabel *Polo;
@property (weak, nonatomic) IBOutlet UILabel *Time;

@end

NS_ASSUME_NONNULL_END
