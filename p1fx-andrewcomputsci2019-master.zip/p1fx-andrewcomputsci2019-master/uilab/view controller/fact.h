//
//  fact.h
//  uilab
//
//  Created by Pegg, Andrew on 12/10/19.
//  Copyright © 2019 Pegg, Andrew. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface fact : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *outputFact;

@end

NS_ASSUME_NONNULL_END
